﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

/// <summary>
/// Descripción breve de IRepository
/// </summary>
public interface IRepository:IDisposable
{
    TEntity Create<TEntity>(TEntity objCreate) where TEntity : class;
    bool Delete<TEntity>(TEntity objDelete) where TEntity : class;
    bool Update<TEntity>(TEntity objUpdate) where TEntity : class;
    TEntity Retrieve<TEntity>(Expression<Func<TEntity, bool>> criteria) where TEntity : class;
    List<TEntity> Filter<TEntity>(Expression<Func<TEntity, bool>> criteria) where TEntity : class;

}