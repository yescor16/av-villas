﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de ILista
/// </summary>
public interface ILista
{
    TEntity Listar<TEntity>() where TEntity : class;
}