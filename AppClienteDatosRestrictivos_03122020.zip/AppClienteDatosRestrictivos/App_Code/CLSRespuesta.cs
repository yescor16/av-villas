﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de EnumRespuesta
/// </summary>
public class CLSRespuesta 
{
    

    public enum codigo_respuesta { 
        correcto = 0000,
        error = 9696
    }

	public CLSRespuesta()
	{
		
	}
    public codigo_respuesta codigo { get; set; }
    public string descripcion { get; set; }
    


  
}