﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de CLSCliente
/// </summary>
public class CLSCliente
{ /*LAURAN70ruizc*/

    public int tipoDocumento { get; set; }
    public string numeroDocumento { get; set; }
    public int tipoPersona { get; set; }
    public string nombreRazonSocial { get; set; }
    public string primerNombre { get; set; }
    public string segundoNombre { get; set; }
    public string primerApellido { get; set; }
    public string segundoApellido { get; set; }
    public string lugarExpedicionDocumento { get; set; }

    //Constructor
	public CLSCliente()
	{
        
        this.tipoDocumento = 0;
        this.numeroDocumento = "";
        this.tipoPersona = 0;
        this.nombreRazonSocial = "";
        this.primerNombre = "";
        this.segundoNombre = "";
        this.primerApellido = "";
        this.segundoApellido = "";
        this.lugarExpedicionDocumento = "";
	}

   


}