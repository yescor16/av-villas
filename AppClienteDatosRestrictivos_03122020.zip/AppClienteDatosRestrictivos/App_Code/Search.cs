﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Search
/// </summary>
public interface Search
{
    List<CLSCliente> ConsumirServicio(CLSCliente cliente);
    //public abstract  List<TEntity> Listar<TEntity>() where TEntity : class;
}