﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de MaintainGrupoAval
/// </summary>
public class MaintainGrupoAval
{
	public MaintainGrupoAval()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
}