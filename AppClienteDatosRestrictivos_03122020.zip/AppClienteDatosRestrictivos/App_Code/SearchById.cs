﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de SearchById
/// </summary>
public class SearchById : Search
{
	
    public List<CLSCliente> ConsumirServicio(CLSCliente cliente)
    {
        List<CLSCliente> lstCliente = new List<CLSCliente>();

        for (int i = 0; i < 1; i++)
        {
            CLSCliente objCliente = new CLSCliente();
            objCliente.tipoDocumento = 3;
            objCliente.numeroDocumento = "" + 10 + i;
            objCliente.tipoPersona = 1;
            objCliente.nombreRazonSocial = "";
            objCliente.primerNombre = "LUIS " + i;
            objCliente.segundoNombre = "EDUARDO " + i;
            objCliente.primerApellido = "CORTES " + i;
            objCliente.segundoApellido = "I " + i;
            objCliente.lugarExpedicionDocumento = "BOGOTA " + i;
            lstCliente.Add(objCliente);
        }

        return lstCliente;
    }
}