﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
 
/// <summary>
/// Descripción breve de WSDatosRestrictivos
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
 [System.Web.Script.Services.ScriptService]
public class WSDatosRestrictivos : System.Web.Services.WebService {

    public WSDatosRestrictivos () {

        //Elimine la marca de comentario de la línea siguiente si utiliza los componentes diseñados 
        //InitializeComponent(); 
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public string HelloWorld() {
        return "Hola a todos";
    }
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public String ObtenerListaClientes(int tipoSearch, CLSCliente cliente)
    {

        Search objSearch;
        JavaScriptSerializer js = new JavaScriptSerializer();

        if (tipoSearch == 1)
        {
            objSearch = new SearchById();
        }
        else {
            objSearch = new SearchByName();
        }

        string json = js.Serialize(objSearch.ConsumirServicio(cliente));
        return json;
    }
    
}
